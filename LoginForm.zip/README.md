# TimCo Retail Manager
A retail management system built by TimCo Enterprise Solutions
